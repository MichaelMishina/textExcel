/**
 * Created by bal_mcmishina on 3/8/2016.
 */

public class FormulaCell extends Cell {
    public String formula;

    public FormulaCell(String originalData) {
        super(originalData);
    }






    }

